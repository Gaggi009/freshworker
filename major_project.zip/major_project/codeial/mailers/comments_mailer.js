const nodemailer = require('../config/nodemailer');


exports.newComment = (comment) =>{
    console.log('inside newComment mailer', comment);

    nodemailer.transporter.sendMail({
        from:'gjsk1999@gamil.com',
        to: comment.user.email,
        subject: 'New Comment Publish',
        html:'<h1>Your Comment Is Now Publish </h1>'
    },(err,info) => {
        if(err){console.log('error in sending the email',err); return;}

        console.log('Message sent', info);
        return;
    }
    )
}