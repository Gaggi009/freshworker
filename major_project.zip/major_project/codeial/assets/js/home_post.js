{
    // method to submit the form using Ajax
    let createPost=function(){
        let newPostform=$('#new-post-form');

        newPostform.submit(function(e){
            e.preventDefault();

            $.ajax({
                type:'post',
                url:'/posts/create',
                data: newPostform.serialize(),
                success: function(data){
                    let newPost = newPostDom(data.data.post);
                    $('#post-list-container').prepend(newPost)
                },error: function(err){
                    console.log(err.responseText)
                }
            })
        })
    }

    // method to create the post in DOM
    let newPostDom = function(posts){
        return $(`<li id="post-${posts._id}">
                    
                    <small>
                            <a class="delete-post-button" href="/posts/destroy/${posts._id}">X</a>
                    </small>
                    
                    <p>
                         ${posts.content}
                <br>
                <small>
                        ${posts.user.name}
                </small>
                    </p>
                    <div>
                            <section>
                                    <h5>
                                            Comments
                                    </h5>
                                    <form action="/comments/create" id="new-comment-form" method="POST" >
                                            <input type="text" name="content" placeholder="Type Here to Add Comment" required>
                                            <input type="hidden" name="post" value="${posts._id}">
                                            <input type="submit" value="Post">
                                    </form>
                                    <div>
                                            <ul id="posts-comments-${posts._id}">
                                                    
                                            </ul>
                                    </div>
                            </section>
                    </div>
       
    </li>`)
    }


    let deletePost = function(){
        
    }



    createPost();
}