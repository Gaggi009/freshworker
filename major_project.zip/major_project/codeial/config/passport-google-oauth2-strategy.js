const passport = require('passport');
const googleStrategy = require('passport-google-oauth').OAuth2Strategy;
const crypto = require('crypto');
const User = require('../models/users');

passport.use(new googleStrategy({
    clientID: "370034357071-2reen4qh4p1qcb3s009u9sns9e5ihfnp.apps.googleusercontent.com",
    clientSecret: "x530MZoUUjMjB49xJX1OgtEC",
    callbackURL: "http://localhost:8000/users/auth/google/callback"
},
    function(accessToken , refreshToken , profile , done){
        User.findOne({email: profile.emails[0].value}).exec(function(err,user){
            if(err){
                console.log ('error in google startegy passport', err);
                return;
            }
            console.log(profile);

            if(user){
                return done(null,user);
            }else {
                User.create({
                    name: profile.displayName,
                    email: profile.emails[0].value,
                    password: crypto.randomBytes(20). toString('hex')
                },function(err,user){
                    if(err){console.log('error in creating the user',err)}

                    return done(null,user);
                });
            }
        });
    }
));

module.exports = passport;